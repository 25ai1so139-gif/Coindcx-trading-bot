# Phase 4 chronological backtest report

Status: **COMPLETE_SYNTHETIC_ONLY**
Run ID: f4a67faa871df804796e47281273b9ef81aaec87abedf093925a46a1b12f6922

Data kind: **synthetic** / synthetic
Source: generated mathematical waveform; not market data
CSV SHA-256: d422f685ad886b56010ed212c8c16b863455c82e62cc1b90e0f5ba62330c25f6; source SHA-256: bda88c0941213f8b98a87b2fcbfef561831069b3bee7936149907d63bc050863
Quality: ELIGIBLE; liquidity: NOT_ASSESSED
Symbol: SYNTHETIC-INR; timeframe: 15m
Strategy: momentum; parameters: {"lookback": 12, "threshold": "0.01"}
Configuration: {"account_currency": "INR", "amount_type": "margin", "daily_loss_amount": "40", "daily_loss_limit": "0.02", "fee_rate": "0.001", "leverage": "1", "margin_amount": "100", "max_drawdown": "0.05", "max_leverage": "3", "max_margin_fraction": "0.25", "max_planned_risk": "20", "max_trades_per_day": 3, "min_history_bars": 2880, "mode": "backtest", "risk_per_trade": "0.005", "slippage_rate": "0.001", "starting_capital": "2000", "stop_loss_fraction": "0.02", "strategy": "momentum", "timeframe": "15m"}

independent fresh INR accounts, no carried positions; prior completed candles warm indicators only; force-close at each period end with costs
parameters fixed before evaluation; no optimizer or final-test parameter ranking; operator must preserve untouched-test discipline across runs

## Separate period results

| Variant | Period | Start (inclusive UTC) | End (exclusive UTC) | Bars | Final INR | Net INR | Fees INR | Slippage INR | Drawdown % | Daily halts |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| baseline | train | 2024-01-31 00:00:00+00:00 | 2024-03-01 00:00:00+00:00 | 2880 | 2226.228167828817830641094754 | 226.228167828817830641094754 | 11.8380661777829419897508456 | 11.8383160823330309235544 | 0.129891727222424416605762300 | 0 |
| baseline | validation | 2024-03-01 00:00:00+00:00 | 2024-03-31 00:00:00+00:00 | 2880 | 2229.88181997695368829160 | 229.88181997695368829160 | 11.64152327938910542840 | 11.64177644450880628 | 0.1276790845699880593639048808 | 0 |
| baseline | test | 2024-03-31 00:00:00+00:00 | 2024-04-30 00:00:00+00:00 | 2880 | 2234.45160618421884450341 | 234.45160618421884450341 | 11.84629785352226488659 | 11.84655599798230061 | 0.1295491504373145220978557836 | 0 |
| cost_stress | train | 2024-01-31 00:00:00+00:00 | 2024-03-01 00:00:00+00:00 | 2880 | 2202.447550902026576363246624 | 202.447550902026576363246624 | 23.6521993874415682374413760 | 23.6531983992363230553120 | 0.154656971512055964265668800 | 0 |
| cost_stress | validation | 2024-03-01 00:00:00+00:00 | 2024-03-31 00:00:00+00:00 | 2880 | 2206.39284003534676962076 | 206.39284003534676962076 | 23.25930417274414883924 | 23.26031582258427154 | 0.1477991911102515835857208329 | 0 |
| cost_stress | test | 2024-03-31 00:00:00+00:00 | 2024-04-30 00:00:00+00:00 | 2880 | 2210.54892995032212964200 | 210.54892995032212964200 | 23.66843461893271415800 | 23.66946616625565620 | 0.1497547224979543036019888585 | 0 |

## Baseline metrics and references

| Period | Closed trades | Win % | Profit factor | Expectancy INR | Buy-and-hold net INR | Cash net INR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| train | 58 | 98.27586206896551724137931034 | 99.53563863439196159167744614 | 3.900485652220997080018875076 | -116.98904606442663707835 | 0 |
| validation | 57 | 100 | undefined | 4.033014385560591022659649123 | -32.68860836932681071200 | 0 |
| test | 58 | 100 | undefined | 4.042269072141704215576034483 | 122.97220431109177183644 | 0 |

train warmup: 2880 bars from 2024-01-01 00:00:00+00:00; activations: {"daily_loss_limit": 0, "daily_trade_limit": 1, "emergency_shutdown": 0, "max_drawdown": 0}


validation warmup: 2880 bars from 2024-01-31 00:00:00+00:00; activations: {"daily_loss_limit": 0, "daily_trade_limit": 0, "emergency_shutdown": 0, "max_drawdown": 0}


test warmup: 2880 bars from 2024-03-01 00:00:00+00:00; activations: {"daily_loss_limit": 0, "daily_trade_limit": 0, "emergency_shutdown": 0, "max_drawdown": 0}


All trade, equity and activation records are in JSON and CSV. Undefined metrics are JSON null / empty CSV cells.
Cash and buy-and-hold benchmarks use the same period and modeled costs; buy-and-hold has different risk exposure.

## Cost assumptions

{
  "fee_rate": "0.001",
  "slippage_rate": "0.001",
  "schedule_verified": false,
  "rate_basis": "user-configurable fraction of filled notional on EACH entry and exit",
  "fill_basis": "adverse fractional price adjustment on EACH entry and exit",
  "spread": "not separately modeled; no historical bid/ask evidence",
  "funding": "not modeled; no supported funding data or derivatives contract",
  "partial_fills": "not modeled; no order-book/queue evidence",
  "other_costs": "tax, borrow, liquidation and exchange size rules not modeled",
  "leverage": "abstract collateral simulation, not a verified CoinDCX margin product"
}

Cost-stress assumptions (multiplier 2):
{
  "fee_rate": "0.002",
  "slippage_rate": "0.002",
  "schedule_verified": false,
  "rate_basis": "user-configurable fraction of filled notional on EACH entry and exit",
  "fill_basis": "adverse fractional price adjustment on EACH entry and exit",
  "spread": "not separately modeled; no historical bid/ask evidence",
  "funding": "not modeled; no supported funding data or derivatives contract",
  "partial_fills": "not modeled; no order-book/queue evidence",
  "other_costs": "tax, borrow, liquidation and exchange size rules not modeled",
  "leverage": "abstract collateral simulation, not a verified CoinDCX margin product"
}

Development-only parameter scenarios: []

## Limitations

- SYNTHETIC FIXTURES: NOT REAL-MARKET PERFORMANCE
- No order-book/funding/spread history; fixed full fills and cost sensitivity do not establish precise execution realism.
- Zero fee/slippage assumptions remain zero when multiplied; configure positive rates for a useful stress test.
- Stops and daily thresholds can be exceeded by gaps; never clamp reported losses.
- Drawdown/activation telemetry has bar-level ordering, not tick timing; high-water marks omit unknown intrabar highs.
- Train/validation/test accounts are independent; their balances must not be added or portrayed as a continuous portfolio.
- INR only, one symbol per run; no regime attribution or multi-symbol concentration inference.
- Minimum period length is an evidence floor, not proof of statistical significance; no annualized Sharpe/volatility is estimated.
- Leverage is abstract collateral, not a verified exchange product; no liquidation, borrow, taxes, lot sizes or partial fills.
- State and safety latches are in memory per simulation; repeated runs do not share a persistent account.
- Reports describe the supplied history and assumptions; no metric predicts future profitability.

No real orders. No short entries. No claim of future profitability.
