# Phase 4 chronological backtest report

Status: **COMPLETE_SYNTHETIC_ONLY**
Run ID: 2bd0879cb1d4fe2e66f118f0cc1073e0cf6507638693596167224b3fcd21a41a

Data kind: **synthetic** / synthetic
Source: generated mathematical waveform; not market data
CSV SHA-256: d422f685ad886b56010ed212c8c16b863455c82e62cc1b90e0f5ba62330c25f6; source SHA-256: bda88c0941213f8b98a87b2fcbfef561831069b3bee7936149907d63bc050863
Quality: ELIGIBLE; liquidity: NOT_ASSESSED
Symbol: SYNTHETIC-INR; timeframe: 15m
Strategy: sma_cross; parameters: {"fast": 5, "slow": 20}
Configuration: {"account_currency": "INR", "amount_type": "margin", "daily_loss_amount": "40", "daily_loss_limit": "0.02", "fee_rate": "0.001", "leverage": "1", "margin_amount": "100", "max_drawdown": "0.05", "max_leverage": "3", "max_margin_fraction": "0.25", "max_planned_risk": "20", "max_trades_per_day": 3, "min_history_bars": 2880, "mode": "backtest", "risk_per_trade": "0.005", "slippage_rate": "0.001", "starting_capital": "2000", "stop_loss_fraction": "0.02", "strategy": "sma_cross", "timeframe": "15m"}

independent fresh INR accounts, no carried positions; prior completed candles warm indicators only; force-close at each period end with costs
parameters fixed before evaluation; no optimizer or final-test parameter ranking; operator must preserve untouched-test discipline across runs

## Separate period results

| Variant | Period | Start (inclusive UTC) | End (exclusive UTC) | Bars | Final INR | Net INR | Fees INR | Slippage INR | Drawdown % | Daily halts |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| baseline | train | 2024-01-31 00:00:00+00:00 | 2024-03-01 00:00:00+00:00 | 2880 | 2216.11455587677223640054 | 216.11455587677223640054 | 11.62774224283428543946 | 11.62798161311401816 | 0.1332365270235260243760958770 | 0 |
| baseline | validation | 2024-03-01 00:00:00+00:00 | 2024-03-31 00:00:00+00:00 | 2880 | 2216.16933086697497023106 | 216.16933086697497023106 | 11.62779706872583008894 | 11.62803649389025968 | 0.1326249897210638348361099344 | 0 |
| baseline | test | 2024-03-31 00:00:00+00:00 | 2024-04-30 00:00:00+00:00 | 2880 | 2221.59727350755473143205 | 221.59727350755473143205 | 11.83343065443861887795 | 11.83367591881869969 | 0.1335055659926318002797836320 | 0 |
| cost_stress | train | 2024-01-31 00:00:00+00:00 | 2024-03-01 00:00:00+00:00 | 2880 | 2192.66683634548880530392 | 192.66683634548880530392 | 23.23179714904424909608 | 23.23275367459292560 | 0.1533955219625559093608693121 | 0 |
| cost_stress | validation | 2024-03-01 00:00:00+00:00 | 2024-03-31 00:00:00+00:00 | 2880 | 2192.72144720135848391576 | 192.72144720135848391576 | 23.23190658493599584424 | 23.23286332980446024 | 0.1528184753915184669942248815 | 0 |
| cost_stress | test | 2024-03-31 00:00:00+00:00 | 2024-04-30 00:00:00+00:00 | 2880 | 2197.73312173665720898044 | 197.73312173665720898044 | 23.64275163145879451956 | 23.64373170987910650 | 0.1536725690062250488726049110 | 0 |
| parameter_1_development_only | train | 2024-01-31 00:00:00+00:00 | 2024-03-01 00:00:00+00:00 | 2880 | 2380.56639492475745995712 | 380.56639492475745995712 | 11.79235869482159706288 | 11.79276284633806298 | 0.06107230502291945810094442509 | 0 |
| parameter_1_development_only | validation | 2024-03-01 00:00:00+00:00 | 2024-03-31 00:00:00+00:00 | 2880 | 2380.75963004505900127945 | 380.75963004505900127945 | 11.99275232171050735055 | 11.99315706724994137 | 0.05982079489108681482186769528 | 0 |
| parameter_2_development_only | train | 2024-01-31 00:00:00+00:00 | 2024-03-01 00:00:00+00:00 | 2880 | 1988.88478435813406957590 | -11.11521564186593042410 | 11.40028501317788028410 | 11.40029669854395014 | 0.7758752316081675777214187848 | 0 |
| parameter_2_development_only | validation | 2024-03-01 00:00:00+00:00 | 2024-03-31 00:00:00+00:00 | 2880 | 1989.43614575674482644240 | -10.56385424325517355760 | 11.40083692207286741760 | 11.40084915990470614 | 0.7484409433764726240527084734 | 0 |

## Baseline metrics and references

| Period | Closed trades | Win % | Profit factor | Expectancy INR | Buy-and-hold net INR | Cash net INR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| train | 57 | 100 | undefined | 3.791483436434600638605964912 | -116.98904606442663707835 | 0 |
| validation | 57 | 100 | undefined | 3.792444401174999477737894737 | -32.68860836932681071200 | 0 |
| test | 58 | 100 | undefined | 3.820642646681978128138793103 | 122.97220431109177183644 | 0 |

train warmup: 2880 bars from 2024-01-01 00:00:00+00:00; activations: {"daily_loss_limit": 0, "daily_trade_limit": 0, "emergency_shutdown": 0, "max_drawdown": 0}


validation warmup: 2880 bars from 2024-01-31 00:00:00+00:00; activations: {"daily_loss_limit": 0, "daily_trade_limit": 0, "emergency_shutdown": 0, "max_drawdown": 0}


test warmup: 2880 bars from 2024-03-01 00:00:00+00:00; activations: {"daily_loss_limit": 0, "daily_trade_limit": 0, "emergency_shutdown": 0, "max_drawdown": 0}


All trade, equity and activation records are in JSON and CSV. Undefined metrics are JSON null / empty CSV cells.
Cash and buy-and-hold benchmarks use the same period and modeled costs; buy-and-hold has different risk exposure.

## Cost assumptions

{
  "fee_rate": "0.001",
  "slippage_rate": "0.001",
  "schedule_verified": false,
  "rate_basis": "user-configurable fraction of filled notional on EACH entry and exit",
  "fill_basis": "adverse fractional price adjustment on EACH entry and exit",
  "spread": "not separately modeled; no historical bid/ask evidence",
  "funding": "not modeled; no supported funding data or derivatives contract",
  "partial_fills": "not modeled; no order-book/queue evidence",
  "other_costs": "tax, borrow, liquidation and exchange size rules not modeled",
  "leverage": "abstract collateral simulation, not a verified CoinDCX margin product"
}

Cost-stress assumptions (multiplier 2):
{
  "fee_rate": "0.002",
  "slippage_rate": "0.002",
  "schedule_verified": false,
  "rate_basis": "user-configurable fraction of filled notional on EACH entry and exit",
  "fill_basis": "adverse fractional price adjustment on EACH entry and exit",
  "spread": "not separately modeled; no historical bid/ask evidence",
  "funding": "not modeled; no supported funding data or derivatives contract",
  "partial_fills": "not modeled; no order-book/queue evidence",
  "other_costs": "tax, borrow, liquidation and exchange size rules not modeled",
  "leverage": "abstract collateral simulation, not a verified CoinDCX margin product"
}

Development-only parameter scenarios: [{"fast": 3, "slow": 10}, {"fast": 8, "slow": 30}]

## Limitations

- SYNTHETIC FIXTURES: NOT REAL-MARKET PERFORMANCE
- No order-book/funding/spread history; fixed full fills and cost sensitivity do not establish precise execution realism.
- Zero fee/slippage assumptions remain zero when multiplied; configure positive rates for a useful stress test.
- Stops and daily thresholds can be exceeded by gaps; never clamp reported losses.
- Drawdown/activation telemetry has bar-level ordering, not tick timing; high-water marks omit unknown intrabar highs.
- Train/validation/test accounts are independent; their balances must not be added or portrayed as a continuous portfolio.
- INR only, one symbol per run; no regime attribution or multi-symbol concentration inference.
- Minimum period length is an evidence floor, not proof of statistical significance; no annualized Sharpe/volatility is estimated.
- Leverage is abstract collateral, not a verified exchange product; no liquidation, borrow, taxes, lot sizes or partial fills.
- State and safety latches are in memory per simulation; repeated runs do not share a persistent account.
- Reports describe the supplied history and assumptions; no metric predicts future profitability.

No real orders. No short entries. No claim of future profitability.
