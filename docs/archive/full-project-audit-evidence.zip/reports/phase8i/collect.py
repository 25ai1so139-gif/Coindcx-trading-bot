"""Read-only Phase 8I source capture and pure sizing replay; no entry path."""
import argparse
import hashlib
import json
import re
import time
from contextlib import ExitStack
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from fractions import Fraction
from html.parser import HTMLParser
from pathlib import Path
from unittest.mock import patch
from urllib.parse import urlencode
from urllib.request import Request, build_opener

from config import Settings
from data.coindcx import NoRedirect, PublicClient, ROUTES, unsigned_get
from data.schema import epoch_ms, milliseconds, normalize
from exchange.diagnostics import minimum_order_diagnostic
from exchange.instruments import Instrument, discover_instrument
from risk.sizing import size_position


def sha(body):
    return hashlib.sha256(body).hexdigest()


def rational(value):
    return Fraction(Decimal(str(value)))


def independent_bounds(settings, instrument, reference):
    # Independent rational arithmetic checks the documented numerical model,
    # never creates or approves a position and never asserts an exchange fill.
    price = rational(reference)
    equity, margin = rational(settings.starting_capital), rational(settings.margin_amount)
    leverage, fee, slip = map(rational, (settings.leverage, settings.fee_rate, settings.slippage_rate))
    entry = price * (1 + slip)
    stop = entry * (1 - rational(settings.stop_loss_fraction))
    stop_fill = stop * (1 - slip)
    unit_risk = entry - stop_fill + fee * (entry + stop_fill)
    risk = min(equity * rational(settings.risk_per_trade), rational(settings.max_planned_risk))
    quantities = {'margin': min(margin, equity * rational(settings.max_margin_fraction)) * leverage / entry,
                  'risk': risk / unit_risk, 'cash': equity / (entry / leverage + entry * fee)}
    ceiling = min(quantities.values())
    step = rational(instrument.step)
    quantity = (ceiling // step) * step
    needed = max(rational(instrument.min_quantity), rational(instrument.min_notional) / entry)
    lots = -(-needed // step)
    minimum = lots * step
    plan = size_position(settings, settings.starting_capital, Decimal(str(reference)), quantity_step=instrument.step)
    assert rational(plan.quantity) == quantity
    assert rational(plan.notional) == quantity * entry
    assert rational(plan.margin) == quantity * entry / leverage
    assert rational(plan.entry_fee) == quantity * entry * fee
    assert rational(plan.planned_stop_risk) == quantity * unit_risk
    assert quantity < minimum
    rejected = False
    try:
        size_position(settings, settings.starting_capital, Decimal(str(reference)),
                      quantity_step=instrument.step, minimum_quantity=instrument.min_quantity,
                      minimum_notional=instrument.min_notional)
    except ValueError as exc:
        assert str(exc) == 'position is below instrument minimum; never increase risk to fit'
        rejected = True
    assert rejected
    return {'independent_exact_math': 'PASS', 'binding_ceiling': min(quantities, key=quantities.get),
            'candidate_matches_production': True, 'constrained_sizer_rejected': True,
            'minimum_compliant_quantity': str(Decimal(minimum.numerator) / Decimal(minimum.denominator)),
            'no_compliant_lot_within_configured_ceiling': True,
            'risk_budget': str(Decimal(risk.numerator) / Decimal(risk.denominator)),
            'funding_and_executable_fill_verified': False}


def guarded_diagnostics(settings, instrument, reference):
    with ExitStack() as stack:
        for target in ('socket.socket', 'paper_trading.broker.PaperBroker',
                       'exchange.auth.Credentials.from_env', 'backtesting.engine.simulate',
                       'backtesting.experiment.run_experiment'):
            stack.enter_context(patch(target, side_effect=AssertionError('FORBIDDEN_IN_SIZE_REVIEW: ' + target)))
        result = minimum_order_diagnostic(settings, instrument, reference)
        assert result['status'] == 'NO_TRADE' and not result['risk_approved'] and result['orders_submitted'] == 0
        check = independent_bounds(settings, instrument, reference)
        return result, check


class Visible(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, value):
        self.parts.append(value)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    output = args.output
    previous = json.loads(Path('docs/examples/phase8h-evidence.json').read_text())
    settings = Settings()
    old_results = []
    for item in previous['fresh_public_observations']['symbols']:
        instrument = Instrument(**item['instrument'])
        diagnostic, bounds = guarded_diagnostics(settings, instrument, item['normalized_candle']['close'])
        serialized = json.loads(json.dumps(diagnostic, default=str))
        assert serialized == item['size_diagnostic']
        old_results.append({'pair':item['pair'], 'phase8h_reproduction_exact':True,
                            'diagnostic':diagnostic, 'bounds':bounds})

    with build_opener(NoRedirect()).open(Request('https://docs.coindcx.com/',
            headers={'Accept':'text/html','User-Agent':'CoinDCX-Offline-Research/2'}, method='GET'), timeout=20) as response:
        body = response.read(4 * 1024 * 1024 + 1)
        assert len(body) <= 4 * 1024 * 1024 and response.status == 200
        source = {'url':'https://docs.coindcx.com/', 'retrieved_at_utc':datetime.now(timezone.utc).isoformat(),
                  'http':response.status, 'bytes':len(body), 'sha256':sha(body), 'tls_verification':'DEFAULT_ENABLED'}
    (output/'official.html').write_bytes(body)
    sections = {}
    text = body.decode()
    for name in ('markets','markets-details','candles'):
        start = re.search(r'<h[1-6][^>]*id=["\x27]'+name+r'["\x27][^>]*>',text)
        assert start
        end = re.search(r'<h[12][ >]',text[start.end():])
        stop = start.end()+end.start() if end else len(text)
        raw = text[start.start():stop]
        visible = Visible(); visible.feed(raw)
        sections[name] = {'url':'https://docs.coindcx.com/#'+name,'sha256':sha(raw.encode()),
                          'unchanged_from_phase8h':sha(raw.encode()) == previous['official_sections'][name]['html_sha256'],
                          'visible_text':' '.join(''.join(visible.parts).split())}
        (output/(name+'.html')).write_text(raw)
    assert all(item['unchanged_from_phase8h'] for item in sections.values())

    manifest, replies = [], {}
    def capture(route, params=None):
        url = ROUTES[route] + ('?'+urlencode(sorted(params.items())) if params else '')
        time.sleep(.5)
        response = unsigned_get(url, 10)
        name = f'public-{len(manifest)+1:04}.json'
        (output/name).write_bytes(response.body)
        manifest.append({'url':url,'method':'GET','at_utc':datetime.now(timezone.utc).isoformat(),
                         'http':response.status,'file':name,'bytes':len(response.body),'sha256':sha(response.body),
                         'headers':{k:v for k,v in response.headers.items() if k in ('date','etag','content-type','retry-after')}})
        assert response.status == 200
        replies[url] = response
        return PublicClient._decode(response.body)

    capture('markets')
    details = capture('details')
    observed = datetime.fromisoformat(manifest[-1]['at_utc'])
    replay = PublicClient(transport=lambda url, timeout: replies[url], now=lambda:observed, request_interval=0)
    close = observed.replace(minute=observed.minute//15*15,second=0,microsecond=0)
    opened = close-timedelta(minutes=15)
    observations = []
    for pair in ('I-BTC_INR','I-ETH_INR','I-SOL_INR','I-DOGE_INR'):
        instrument = discover_instrument(replay, pair)
        metadata = next(row for row in details if row['pair'] == pair)
        bars = capture('candles', {'pair':pair,'interval':'15m','startTime':epoch_ms(opened),
                                  'endTime':epoch_ms(close)-1,'limit':1})
        assert len(bars) == 1 and milliseconds(bars[0]['time']) == opened
        normalized = normalize({'timestamp':opened,**{k:bars[0][k] for k in ('open','high','low','close','volume')}}, pair)
        assert normalized.closed_at <= observed
        diagnostic, bounds = guarded_diagnostics(settings, instrument, normalized.close)
        observations.append({'pair':pair,'raw_public_instrument':metadata,'instrument':asdict(instrument),
                             'raw_candle':bars[0],'normalized_candle':normalized.row(),
                             'price_kind':'COMPLETED_CANDLE_CLOSE_NOT_EXECUTABLE_QUOTE',
                             'diagnostic':diagnostic,'independent_bounds':bounds})
    result = {'phase':'8I','label':'PUBLIC_OBSERVATIONS_AND_SIZE_ONLY_NO_APPROVAL_OR_FILLS',
              'official_document':source,'official_sections':sections,'request_manifest':manifest,
              'metadata_observed_at_utc':observed,'price_open_utc':opened,'price_close_utc':close,
              'phase8h_reproductions':old_results,'current_public_observations':observations,
              'network_public_gets':len(manifest),'documentation_gets':1,'guarded_diagnostics':True,
              'private_requests':0,'credentials_used':False,'orders_submitted':0,'backtests_run':0,
              'live_trading_enabled':False,'performance':None}
    (output/'evidence.json').write_text(json.dumps(result,default=str,indent=2)+'\n')
    print(json.dumps({'all_http':[r['http'] for r in manifest],'metadata_observed_utc':str(observed),
                     'price_close_utc':str(close),'phase8h_exact_reproductions':len(old_results),
                     'symbols':[{'pair':r['pair'],'reference':r['normalized_candle']['close'],
                                 'diagnostic':r['diagnostic'],'bounds':r['independent_bounds']} for r in observations]},default=str,indent=2))


if __name__ == '__main__':
    main()
